package mobile.testDao;

import org.junit.Test;

import mobile.dao.UserDao;
import mobile.dao.UserDaoImp;

public class TestDao {

	public TestDao() {
		// TODO �Զ����ɵĹ��캯�����
	}

	public void testReg(){
		System.out.println("Register...");
		UserDao ud=new UserDaoImp();
		System.out.println(ud.regist("wuw", "123456"));
	}
	public void testLogin(){
		System.out.println("login...");
		UserDao ud=new UserDaoImp();
		System.out.println(ud.login("wuw", "123456"));
	}
	public void testCheck(){
		System.out.println("checker...");
		UserDao ud=new UserDaoImp();
		System.out.println(ud.checkUser("wuw"));
	}
}
