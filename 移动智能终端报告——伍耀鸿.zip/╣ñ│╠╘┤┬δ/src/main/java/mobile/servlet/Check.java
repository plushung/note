package mobile.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.json.JsonReadContext;

import tools.Checker;

/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Check() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		byte[] b=new byte[1024];
//		request.getInputStream().read(b);
//		String ss=new String(b);
//		System.out.println(request.getHeader("Accept"));
		String ss=request.getParameter("expr");
		System.out.println(ss);
		Checker c=new Checker();
		Integer re=0;
		boolean stats=c.checkExpr(ss+'=');
		response.setHeader("Content-Type", "application/json");
		StringBuilder sb=new StringBuilder();
		sb.append("{\"result\":\"");
		sb.append(stats?"��ȷ ":"����");
		sb.append("\",\"computeResult\":\"");
		sb.append(c.getNum());
		sb.append("\"}");
		response.getWriter().write(sb.toString());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	
	
}
