package tools;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class GetSessionFactory {

	private static SessionFactory sf=null;
	
	public GetSessionFactory() {
		// TODO �Զ����ɵĹ��캯�����
	}

	public static SessionFactory get(){
		if(sf==null){
			sf=new Configuration().configure().buildSessionFactory();
		}
		return sf;
	}
	
	public static void close(){
		if(sf!=null){
			sf.close();
		}
	}
}
