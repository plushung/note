package tools;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.IntStream;

import com.fasterxml.jackson.databind.ser.std.StdKeySerializers.Default;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;
import sun.misc.Unsafe;

public class Checker implements Runnable{

	public LinkedList<Character> sig=null;
	public LinkedList<Integer> num=null;
	
	public Checker() {
		// TODO �Զ����ɵĹ��캯�����
		sig=new LinkedList<>();
		num=new LinkedList<>();
	}
  
	
	public boolean checkExpr(String expr){
		sig=new LinkedList<>();
		num=new LinkedList<>();
		boolean haseq=false;
		boolean ret =false;
		LinkedList<Character> queue=new LinkedList<>();
		Character last=null;
		if(expr.charAt(0)=='-'|expr.charAt(0)=='/'|expr.charAt(0)=='+'|expr.charAt(0)=='*')
			expr='0'+expr;
		for(int i=expr.length()-1;i>=0;i--){
			queue.offer(expr.charAt(i));
		}
		char cur=' ';
		while(!queue.isEmpty()){
			cur=queue.poll();
			
			if(haseq&&cur=='='){
				System.out.println("too much '='");
				return false;
			}
			if(cur=='=')haseq=true;
			switch(cur){
				case '0':case '1':case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
					Character nums=queue.peek();
					int n=cur-'0';
					int pow=1;
					while(nums!=null&&nums>='0'&&nums<='9'){
						nums=queue.poll();
						pow=pow==0?1:pow*10;
						n=n+pow*(nums-'0');
						nums=queue.peek();
					}
					num.push(n);break;
				case '(':{
					char pc=sig.pop();
					while(pc!=')'){
						if(pc=='{'|pc=='}'|pc=='['|pc==']')
							return false;
						if(!compute(pc))return false;
						try{
							pc=sig.pop();
						}catch (NoSuchElementException e) {
							// TODO: handle exception
							System.out.println("error expression");
							return false;
						}
					}break;
				}
				case '[':{
					char pc=sig.pop();
					while(pc!=']'){
						if(pc=='{'|pc=='}')
							return false;
						if(!compute(pc))return false;
						try{
							pc=sig.pop();
						}catch (NoSuchElementException e) {
							// TODO: handle exception
							System.out.println("error expression");
							return false;
						}
					}break;
				}
				case '{':{
					char pc=sig.pop();
					while(pc!='}'){
						if(!compute(pc))return false;
						try{
							pc=sig.pop();
						}catch (NoSuchElementException e) {
							// TODO: handle exception
							System.out.println("error expression");
							return false;
						}
					}break;
				}
				case ')':
				case ']':
				case '}':sig.push(cur);break;
				case '+':
				case '-':{
//					System.out.println("::+- :"+cur+" last:"+last);
					if(last=='+'|last=='-'|last=='*'|last=='/'|last==')'|last=='}'|last==']') return false;
					else {
						char pre=sig.peek();
						if(pre=='*'|pre=='/')
							if(!compute(sig.pop()))return false;
						sig.push(cur);
					}
					break;
				}
				case '/':
				case '*':{
					if(last=='+'|last=='-'|last=='*'|last=='/'|last==')'|last=='}'|last==']') return false;
					else {
						sig.push(cur);
					}
					break;
				}
				case '=':sig.push(cur);
				default :break;
			}
			last=cur;
			}
			Character cc=sig.pop();
			while(cc!='='){
				if(!compute(cc))return false;
				try{
					cc=sig.pop();
				}catch (NoSuchElementException e) {
					// TODO: handle exception
					System.out.println("no '='");
					return false;
				}
				
			}
			return true;
			
		
		}

//	public boolean pair(char s,char c){
//		switch(s){
//		case '(':
//		case '[':
//		case '{':
//		}
//	}
	public int getNum(){
		int re=0;
		try{
			re= num.peek();
		}catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println("no result");
		}
		return re;
	}
	public boolean compute(char oper,int n1,int n2){
		try{
			switch(oper){
				case '-':num.push(n1-n2);break;
				case '+':num.push(n1+n2);break;
				case '/':num.push(n1/n2);break;
				case '*':num.push(n1*n2);break;
				default:return false;
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("compute exception");
			return false;
		}
		
		return true;
	}
	public boolean compute(char oper){
		
		
		try{
			int n1=num.pop();int n2=num.pop();
//			System.out.println(":::compute n1"+n1+" op"+oper+" n2"+n2);
			switch(oper){
				case '-':num.push(n1-n2);break;
				case '+':num.push(n1+n2);break;
				case '/':num.push(n1/n2);break;
				case '*':num.push(n1*n2);break;
				default:return false;
			}
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println("compute exception");
			return false;
		}
		
		return true;
	}
	int s=0;
	public void stackOver(){
		System.out.println(s++);
		stackOver();
	}
	
	public void quickSort(int[]a,int l,int h){
		int mid=(h-l)/2;
		System.out.println("tt:"+l+" "+h);
		
		if(l==h)
			return;
		else{
			partSort(a,l,h);
			quickSort(a,l,mid-1);
			quickSort(a,mid+1,h);
		}
		
	}
	
	public void partSort(int[]a,int l,int h){
		
		int mid=(h-l)/2;
		int []part=new int[h+1];
		int ll=l,lh=h;
		int temp=0;
		if((h-l)==1){
			if(a[l]>a[h]){
				temp=a[h];
				a[h]=a[l];
				a[l]=temp;
			}
		}else	
			while(l<h){
				while(l<mid){
					if(a[l]<=a[mid])
						part[ll++]=a[l++];
					else
						part[lh--]=a[l++];
				}
				while(h>mid){
					if(a[h]<=a[mid])
						part[ll++]=a[h--];
					else
						part[lh--]=a[h--];
				}
			}
//			while(l!=h){
//				while(l<mid&&a[l]<a[mid])
//					l++;
//				if(l<mid&&a[l]>a[mid]){
//					while(h>mid&&a[h]>a[mid])
//						h--;
//					if(h>mid&&a[h]<a[mid]){
//						temp=a[l];
//						a[l]=a[h];
//						a[h]=temp;
//						h--;
//						l++;
//					}else{
//						temp=a[l];
//						a[l]=a[mid];
//						a[mid]=temp;
//						h--;
//						mid=l;
//					}
//				}else{
//					while(h>mid&&a[h]>a[mid])
//						h--;
//					if(h>mid&&a[h]<a[mid]){
//						temp=a[h];
//						a[h]=a[mid];
//						a[mid]=temp;
//						l++;
//						mid=h;
//					}	
//				}
//				System.out.println("l:"+l+" h:"+h);
//			}
		
	}
	
	public static void main(String[] args) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
////		java.util.List<Checker> ll=new ArrayList<>();
////		int n=0;
//		Checker cc=new Checker();
//		cc.stackOver();
////		String ss=new StringBuilder("0+2*(1+2)-[6/(2+1)+3]=").toString();
////		boolean c=cc.checkExpr(ss);
////		System.out.println(c+":"+cc.getNum());
////		while(true){
////			ll.add(new Checker());
////			System.out.println("num:"+(++n));
////		}
//		Map map = new HashMap<>(100, 0.8f);
//        IntStream.range(0, 101).forEach(i -> map.put(i, i));
//        
//        Field field = HashMap.class.getDeclaredField("table");
//        field.setAccessible(true);
//        System.out.println(Array.getLength(field.get(map)));
//		int [] aa={1,10,2,5,4,8,6,3,12,11};
//		Checker cc=new Checker();
//		cc.quickSort(aa, 0, 9);
//		for(int i=0;i<aa.length;i++)
//			System.out.println(aa[i]);
//		Thread[]a=new Thread[Integer.MAX_VALUE];
		int i=0;
//		while(true){
//			System.out.println(i++);
//			new Thread(new Checker()).start();
//			a[i++].start();
			Enhancer enh=new Enhancer();
			enh.setSuperclass(Checker.class);
			enh.setUseCache(false);
			enh.setCallback(new MethodInterceptor() {
				
				@Override
				public Object intercept(Object arg0, Method arg1, Object[] arg2, MethodProxy arg3) throws Throwable {
					// TODO �Զ����ɵķ������
					Checker cc=new Checker();
					System.out.println("method:"+arg1.getName());
					Object o=arg3.invokeSuper(arg0, arg2);
					System.out.println("done:"+arg1.getName());
					return o;
				}
			});
			enh.create();
			System.gc();
//			ccp.checkExpr("123-88");
//		}
		
		
		
	}


	@Override
	public void run() {
		// TODO �Զ����ɵķ������
//		checkExpr("123456+55");
		while(true);
	}
}  
	

