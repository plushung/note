/**
 * 
 */

$(document).ready(function(){
	var show=$("#inputBar")
	var cr=$("#con button")
	var tomain=$("#tomain")
	var comp=$("#comp")
	var showCY=$("#showCY")
	var inputCY=$("#inputCY")
	var reflashCY=$("#reflashCY")
	var loginbtn=$("#login")
	var register=$("#register")
	var fetchlist=$("#fetchlist")
	var uitems=$(".uitem")
	loginbtn.on("click",loginOrRegister)
	register.on("click",loginOrRegister)
	fetchlist.on("click",getList)
	inputCY.on("click",iCY)
	reflashCY.on("click",askCY)
	var btnCY=$("#btnCY")
	btnCY.on("click",bCY)
	if($(showCY).val()==""){
		$(showCY).val(askCY());
	}
	console.log(cr)
	for(i=0;i<cr.length;i++){
		console.log($(cr[i]))
		var bt=$(cr[i]);
		var id=bt.attr("id");
		var text=bt.text();
		bt.on("click",clickBut).width("25%")
	}
	
	function menu(ev){
		getMenu($("body:first"),"/mobile/html/index.html")
	}
	function comp(ev){
		alert("cc")
//		getMenu($("body"),"/mobile/html/btmobi.html")
	}
	
	function clickBut(ev){
		$("#response").text('');
		console.log(ev)
		var expr=new String(show.val());
		console.log(expr)
		var sig=$(ev.target).attr("id")
		switch(sig){
		case "n1":case "n2":case "n3":case "n4":case "n5":case "n6":case "n7":case "n8":case "n9":
			show.val(expr+$(ev.target).text());break;
		case "add":case "sub":case "div":case "mul":
			var c=expr[expr.length-1];
			if(c==''|c=='('|c=='{'|c=='[')
				expr=expr+'0'+$(ev.target).text();
			else
				expr=expr+$(ev.target).text();
			show.val(expr)
			break;
		case "n0":if(expr!='')show.val(expr+$(ev.target).text());break;
		case "eq":sendTo(expr,$("#response"));
		case "ok":show.val('');break;
		case "esc":expr=expr.substr(0,expr.length-1);show.val(expr);break;
		case "lxq":case "lmq":case "lbq":case "xq":case "mq":case "bq":
			show.val(expr+$(ev.target).text());break;
		default:break;
		}
	}
	
	
	function sendTo(data,show){
//		$.post("/mobile/Check",JSON.parse(data),{"accept":"application/json"})
		var ddd={"expr":data}
		var ret;
		$.ajax({
		    url:"/mobile/Check",
		    type:'post',
		    dataType:'json',
		    data:ddd,
		    success:function(da,sta,xhr){
				console.log(da)
				ret=JSON.parse(xhr.responseText)
				var ok=ret.result
				var resu=ret.computeResult
				if(ok=="needlogin"){
					$(show).html("<p>"+"you should login first"+"</p>")
				}else{
					$(show).html("<p>"+ok+" result \n is:"+resu+"</p>")
				}
			}
		});
		return ret;
	}
	
	function loginOrRegister(ev){
		var das={"action":$(ev.target).attr("id"),"name":$("#name").val(),"pass":$("#pass").val()}
		console.log(das)
		$.ajax({
			url:"/mobile/LoginOrRegister",
			type:"post",
			data:das,
			dataType:"json",
			success:function(da,sta,xhr){
				var rec=JSON.parse(xhr.responseText)
				console.log(rec)
				switch(rec.action){
				case "login":{
					if(rec.status=="true")
						$("#loginbody").load("/mobile/html/index.html")
					else{
						switch(rec.code){
						case "-1":$("#nl").text(" "+rec.describe);break;
						case "4":$("#pl").text($("#pl").text()+" "+rec.describe);break;
						}
					}
					break;
				}
				case "register":{
					if(rec.status=="true")
						$("#loginbody").load("/mobile/html/index.html")
					else{
						switch(rec.code){
						case "-1":$("#nl").text(" "+rec.describe);break;
						case "4":$("#pl").text(" "+rec.describe);break;
						}
					}
					break;
				}
				}
			}
			
		})
	}
	function iCY(){
		$(inputCY).val("")
	}
	function bCY(){
			var da={"content":$(inputCY).val()}
			$.ajax({
		 	   	url:"/mobile/CheckCY",
		 	   	type:'post',
			    dataType:'json',
			    data:da,
			    success:function(da,sta,xhr){
					console.log(da)
					var rec=JSON.parse(xhr.responseText);
					if(rec.result=="needlogin"){
						$(inputCY).val("请先登录")
					}
					else if(rec.result=="false"){
						$(inputCY).val($(inputCY).val()+":答案错误")
//						askCY()
					}
					else if(rec.result=="slow"){
						$(inputCY).val($(inputCY).val()+":回答太慢了")
						askCY()
					}
					else{
						$(showCY).val(rec.result)
						$(inputCY).val(rec.result+":正确")
					}
				}
			});
			
		
		
//		$(showCY).val($(inputCY).val())
	}
	
	function askCY(){
		var da={"init":"true","content":$(inputCY).val()}
		var ret;
		$.ajax({
	 	   	url:"/mobile/CheckCY",
	 	   	type:'post',
		    dataType:'json',
		    data:da,
		    success:function(da,sta,xhr){
				console.log(da)
				var rec=JSON.parse(xhr.responseText);
				if(rec.initresult=="false")
					$(showCY).val("error")
				else
					$(showCY).val(rec.initresult)
				ret=rec.initresult
				
			}
		});
		return ret;
	}
	function getList(){
		
		$.ajax({
	 	   	url:"/mobile/UserList",
	 	   	type:'post',
		    dataType:'json',
		    data:{},
		    success:function(da,sta,xhr){
				console.log(da)
				$("#userlist").empty();
				var rec=JSON.parse(xhr.responseText);
				for(var sf in da){
					console.log(sf)
					var ad=$("<tr id="+da[sf]["name"]+"><td colspan='1'><a id="+da[sf]["name"]+" class='btn btn-block btn-primary'>del</a></td><td colspan='2'><label>"+da[sf]["name"]+"</label></td></tr>")
					$("#userlist").append(ad)
					$("tr#"+da[sf]["name"]).on("click",del);
				}
				
			}
		});	
	}
function del(ev){
		console.log(ev)
		
		var dat={"target":$(ev.target).attr("id")}
		$.ajax({
			url:"/mobile/Delete",
			data:dat,
			type:"post",
			datatype:"json",
			success:function(da,sta,xhr){
				console.log(da)
				$(ev.target).remove();
			}
		});
	
	}
	function getMenu(show,url){
//		$.post("/mobile/Check",JSON.parse(data),{"accept":"application/json"})
		var ret;
		$.ajax({
		    url:url,
		    type:'get',
		    dataType:'json',
		    data:"",
		    success:function(da,sta,xhr){
				console.log(da)
				$(show).html(xhr.responseText)
			}
		});
		return ret;
	}
	
})




























