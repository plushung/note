package mobile.filter;

import java.io.IOException;
import javax.servlet.*;

public class CharacterEncodingFilter implements Filter {

	protected String encoding = null; // 定义编码格式变量
	protected FilterConfig filterConfig = null; // 定义过滤器配置对�?

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig; // 初始化过滤器配置对象
		this.encoding = filterConfig.getInitParameter("encoding"); // 获取配置文件中指定的编码格式
	}

	// 过滤器的接口方法，用于执行过滤业�?
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if (encoding != null) {
			request.setCharacterEncoding(encoding); // 设置请求的编�?
			// 设置应答对象的内容类型（包括编码格式�?
			response.setContentType("text/html; charset=" + encoding);
		}
		chain.doFilter(request, response); // 传�?�给下一个过滤器
	}

	public void destroy() {
		this.encoding = null;
		this.filterConfig = null;
	}

}
