package mobile.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import mobile.dao.UserDaoImp;

/**
 * Servlet Filter implementation class LoginFilter
 */

public class LoginFilter implements Filter {

    /**
     * Default constructor. 
     */
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		Cookie[] ck=((HttpServletRequest)request).getCookies();
		String role=null;
		UserDaoImp um=new UserDaoImp();
		System.out.println("loginfilter");
		for(Cookie c:ck){
			if(c.getName().equals("role")){
				role=c.getValue();
			}
		}
		if(role!=null&&(role.equals("user")|role.equals("admin"))){
			System.out.println("role:"+role);
			chain.doFilter(request, response);
		}else{
			System.out.println("needlogin:"+role);
			response.getWriter().println("{\"result\":\"needlogin\"}");
		}
		
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
