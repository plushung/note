package mobile.servlet;

import java.io.IOException;
import java.util.concurrent.locks.ReentrantLock;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import mobile.dao.UserDaoImp;
import oracle.jrockit.jfr.events.RequestableEventEnvironment;

/**
 * Servlet implementation class CheckCY
 */
@WebServlet("/CheckCY")
public class CheckCY extends HttpServlet {
	private static final long serialVersionUID = 1L;
    String lastCY=" ";
    static final ReentrantLock lock=new ReentrantLock(true);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckCY() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
				String CY=request.getParameter("content");
				boolean init=Boolean.parseBoolean(request.getParameter("init"));
				if(CY!=null);
					System.out.println(lastCY+":"+CY+":"+init);
				if(init==true){
					if(lastCY==" "){
						response.getWriter().println("{\"initresult\":\"����ǰé\"}");
						lastCY="����ǰé";
					}
					else
						response.getWriter().println("{\"initresult\":\""+lastCY+"\"}");
				}else{
					if(lock.tryLock()){
						try{
							if(CY!=""&&CY.charAt(0)==lastCY.charAt(3)){
								response.getWriter().println("{\"result\":\""+CY+"\"}");
								lastCY=CY;
							}else{
								response.getWriter().println("{\"result\":\"false\"}");
							}
						}catch(Exception e){
							System.out.println(e.getMessage());
						}finally{
							lock.unlock();
						}
					}else{
						response.getWriter().println("{\"result\":\"slow\"}");
					}
				}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
