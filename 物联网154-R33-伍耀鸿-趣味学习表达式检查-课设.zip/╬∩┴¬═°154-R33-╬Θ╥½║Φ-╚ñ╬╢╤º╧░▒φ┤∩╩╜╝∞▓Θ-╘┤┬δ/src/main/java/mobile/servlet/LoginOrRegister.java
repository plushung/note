package mobile.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mobile.dao.UserDaoImp;

/**
 * Servlet implementation class LoginOrRegister
 */
@WebServlet("/LoginOrRegister")
public class LoginOrRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserDaoImp ud=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginOrRegister() {
        super();
        ud=new UserDaoImp();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getParameter("action");
		String user=request.getParameter("name");
		String pass=request.getParameter("pass");
		System.out.println(action+user+pass);
		StringBuilder sb=new StringBuilder();
		sb.append("{\"action\":\"");
		switch(action){
		case "login":{
			sb.append(action);
			
			boolean sta=ud.checkUser(user);
			int code=0;
			String desc="";
			if(!sta){
				code=-1; //-1 �û�������
				desc="�û�������";
			}else{
				if(sta=ud.login(user, pass)){
					code=2;
					desc="�ɹ�";
					if(user.equals("admin")){
						response.addCookie(new Cookie("role", "admin"));
						sb.append("\",\"role\":\"");
						sb.append("admin");
					}else{
						response.addCookie(new Cookie("role", "user"));
						sb.append("\",\"role\":\"");
						sb.append("user");
					}
				}
				else{
					code=4; desc="�������";
				}
			}
			sb.append("\",\"status\":\"");
			sb.append(sta);
			sb.append("\",\"code\":\"");
			sb.append(code);
			sb.append("\",\"describe\":\"");
			sb.append(desc);
			sb.append("\"}");
			break;
		}
		case "register":{
			sb.append(action);
			sb.append("\",\"status\":\"");
			boolean sta=!ud.checkUser(user);
			int code=0;
			String desc="";
			if(!sta){
				code=-1;	//-1 �û��Ѵ���
				desc="�û��Ѵ���";
			}else{
				if(sta=ud.regist(user, pass)){
					code=2;desc="�ɹ�";
				}
				else{
					code=4; desc="ע��ʧ��";
				}
			}
			sb.append(sta);
			sb.append("\",\"code\":\"");
			sb.append(code);
			sb.append("\",\"describe\":\"");
			sb.append(desc);
			sb.append("\"}");
			break;
		}
		default:{
			sb.append("UnKnowAction");
			sb.append("\",\"status\":\"");
			sb.append(false);
			sb.append("\",\"code\":\"");
			sb.append(-2);
			sb.append("\",\"describe\":\"");
			sb.append("δ֪����");
			sb.append("\"}");
			break;
		}
		}
		response.getWriter().println(sb.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
