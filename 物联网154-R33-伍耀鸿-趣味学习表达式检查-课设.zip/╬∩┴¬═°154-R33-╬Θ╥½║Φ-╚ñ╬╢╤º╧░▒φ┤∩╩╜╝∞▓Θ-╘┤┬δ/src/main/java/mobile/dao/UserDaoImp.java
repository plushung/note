package mobile.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.QueryTimeoutException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

import mobile.model.User;
import tools.GetSessionFactory;

public class UserDaoImp implements UserDao {

	private SessionFactory sf=null;
	
	
	public UserDaoImp() {
		// TODO �Զ����ɵĹ��캯�����
		sf=GetSessionFactory.get();
	}
	
	private Session getSession(){
		//session Ϊһ��connection
		//transaction Ϊconnection.commit����ǰ�Ĳ���
		Session s=sf.getCurrentSession();
			if(!s.getTransaction().isActive()){
				s.getTransaction().begin();
			}
		return s;
	}

	@Override
	public boolean login(String name, String pass) {
		// TODO �Զ����ɵķ������
		boolean ret=false;
		Session s=getSession();
		Query<User> q=s.createQuery("from User where name=:name",User.class );
		q.setParameter("name", name);
		User u=q.getSingleResult();
		if(u.getPass().equals(pass))
			ret=true;
		return ret;
	}

	public boolean delete(String name) {
		// TODO �Զ����ɵķ������
		boolean ret=false;
		Session s=getSession();
		Query<User> q=s.createQuery("from User where name=:name",User.class );
		q.setParameter("name", name);
		User u=q.getSingleResult();
		s.delete(u);
		s.flush();
		s.getTransaction().commit();
		ret=true;
		return ret;
	}
	
	@Override
	public boolean checkUser(String name) {
		// TODO �Զ����ɵķ������
		boolean ret=false;
		Session s=getSession();
		Query<User> q=s.createQuery("from User where name=:name",User.class );
		q.setParameter("name",name);
		try{
			User u=q.getSingleResult();
			ret=true;
		}catch (NoResultException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (NonUniqueResultException  e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			ret=true;
		}
			
		return ret;
	}

	public List<User> getList() {
		// TODO �Զ����ɵķ������
		boolean ret=false;
		List< User> ls=null;
		Session s=getSession();
		Query<User> q=s.createQuery("from User",User.class );
		try{
			ls=q.getResultList();
			System.out.println(ls.size());
			ret=true;
		}catch (IllegalStateException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}catch (QueryTimeoutException  e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
			ret=true;
		}
			
		return ls;
	}
	
	@Override
	public boolean regist(String name, String pass) {
		// TODO �Զ����ɵķ������
		boolean ret=false;
		User u=new User();
		u.setName(name);
		u.setPass(pass);
		Session s=getSession();
		if(!checkUser(name)){
			s.save(u);
			s.getTransaction().commit();
			ret=true;
		}
		return ret;
	}

}
